package com.toyproject.hccp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HccpApplicationTests {

	@Test
	void contextLoads() {
	}

}
